////////////////////////////////////////////////////////////////////////////////
// SLAB_HID_Device.h
////////////////////////////////////////////////////////////////////////////////

#ifndef SLAB_HID_Device_H
#define SLAB_HID_Device_H

/////////////////////////////////////////////////////////////////////////////
// Includes
/////////////////////////////////////////////////////////////////////////////

#include "Types.h"

// FIXME This is a Windows thing, need to find out one day what it's for
#define INFINITE            0xFFFFFFFF  // Infinite timeout

/////////////////////////////////////////////////////////////////////////////
// Definitions
/////////////////////////////////////////////////////////////////////////////

typedef BYTE SLAB_HID_DEVICE_STATUS;

// Return Codes
#define HID_DEVICE_SUCCESS                      0x00
#define HID_DEVICE_NOT_FOUND                    0x01
#define HID_DEVICE_NOT_OPENED                   0x02
#define HID_DEVICE_ALREADY_OPENED               0x03
#define HID_DEVICE_TRANSFER_TIMEOUT             0x04
#define HID_DEVICE_TRANSFER_FAILED              0x05
#define HID_DEVICE_CANNOT_GET_HID_INFO          0x06
#define HID_DEVICE_HANDLE_ERROR                 0x07
#define HID_DEVICE_INVALID_BUFFER_SIZE          0x08
#define HID_DEVICE_SYSTEM_CODE                  0x09
#define HID_DEVICE_UNSUPPORTED_FUNCTION		0x0A
#define HID_DEVICE_UNKNOWN_ERROR                0xFF

// Max number of USB Devices allowed
#define MAX_USB_DEVICES                         64

// Max number of reports that can be requested at time
#define MAX_REPORT_REQUEST_XP			512
#define MAX_REPORT_REQUEST_2K			200

#define DEFAULT_REPORT_INPUT_BUFFERS            0

// String Types
#define HID_VID_STRING                          0x01
#define HID_PID_STRING                          0x02
#define HID_PATH_STRING                         0x03
#define HID_SERIAL_STRING                       0x04
#define HID_MANUFACTURER_STRING                 0x05
#define HID_PRODUCT_STRING                      0x06

// String Lengths
#define MAX_VID_LENGTH                          5
#define MAX_PID_LENGTH                          5
#define MAX_PATH_LENGTH                         512
#define MAX_SERIAL_STRING_LENGTH                256
#define MAX_MANUFACTURER_STRING_LENGTH          256
#define MAX_PRODUCT_STRING_LENGTH               256
#define MAX_INDEXED_STRING_LENGTH		256
#define MAX_STRING_LENGTH                       512

/////////////////////////////////////////////////////////////////////////////
// Typedefs
/////////////////////////////////////////////////////////////////////////////

typedef void* HID_DEVICE;

/////////////////////////////////////////////////////////////////////////////
// Exported Functions
/////////////////////////////////////////////////////////////////////////////

#ifdef __cplusplus
extern "C"
{
#endif // __cplusplus

DWORD HidDevice_GetNumHidDevices(WORD vid, WORD pid);
BYTE HidDevice_GetHidString(DWORD deviceIndex, WORD vid, WORD pid, BYTE hidStringType, char* deviceString, DWORD deviceStringLength);
BYTE HidDevice_GetHidIndexedString(DWORD deviceIndex, WORD vid, WORD pid, DWORD stringIndex, char* deviceString, DWORD deviceStringLength);
BYTE HidDevice_GetHidAttributes(DWORD deviceIndex, WORD vid, WORD pid, WORD* deviceVid, WORD* devicePid, WORD* deviceReleaseNumber);
void HidDevice_GetHidGuid(void* hidGuid);
BYTE HidDevice_GetHidLibraryVersion(BYTE* major, BYTE* minor, BOOL* release);

BYTE HidDevice_Open(HID_DEVICE* device, DWORD deviceIndex, WORD vid, WORD pid, DWORD numInputBuffers);
BOOL HidDevice_IsOpened(HID_DEVICE device);
HANDLE HidDevice_GetHandle(HID_DEVICE device);

BYTE HidDevice_GetString(HID_DEVICE device, BYTE hidStringType, LPSTR deviceString, DWORD deviceStringLength);
BYTE HidDevice_GetIndexedString(HID_DEVICE device, DWORD stringIndex, char* deviceString, DWORD deviceStringLength);
BYTE HidDevice_GetAttributes(HID_DEVICE device, WORD* deviceVid, WORD* devicePid, WORD* deviceReleaseNumber);

BYTE HidDevice_SetFeatureReport_Control(HID_DEVICE device, BYTE* buffer, DWORD bufferSize);
BYTE HidDevice_GetFeatureReport_Control(HID_DEVICE device, BYTE* buffer, DWORD bufferSize);
BYTE HidDevice_SetOutputReport_Interrupt(HID_DEVICE device, BYTE* buffer, DWORD bufferSize);
BYTE HidDevice_GetInputReport_Interrupt(HID_DEVICE device, BYTE* buffer, DWORD bufferSize, DWORD numReports, DWORD* bytesReturned);
BYTE HidDevice_GetInputReport_Interrupt_WithTimeout(HID_DEVICE device, BYTE* buffer, DWORD bufferSize, DWORD numReports, DWORD* bytesReturned, DWORD TimeoutMSec);
BYTE HidDevice_SetOutputReport_Control(HID_DEVICE device, BYTE* buffer, DWORD bufferSize);
BYTE HidDevice_GetInputReport_Control(HID_DEVICE device, BYTE* buffer, DWORD bufferSize);

WORD HidDevice_GetInputReportBufferLength(HID_DEVICE device);
WORD HidDevice_GetOutputReportBufferLength(HID_DEVICE device);
WORD HidDevice_GetFeatureReportBufferLength(HID_DEVICE device);
DWORD HidDevice_GetMaxReportRequest(HID_DEVICE device);
BOOL HidDevice_FlushBuffers(HID_DEVICE device);
BOOL HidDevice_CancelIo(HID_DEVICE device);

void HidDevice_GetTimeouts(HID_DEVICE device, DWORD* getReportTimeout, DWORD* setReportTimeout);
void HidDevice_SetTimeouts(HID_DEVICE device, DWORD getReportTimeout, DWORD setReportTimeout);

BYTE HidDevice_Close(HID_DEVICE device);

#ifdef __cplusplus
}
#endif // __cplusplus

#endif // SLAB_HID_Device_H
